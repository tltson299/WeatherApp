package com.a19125063_19125119.weathermodel;

public class Wind {
    public double speed;
    public int deg;
    public double gust;
}
