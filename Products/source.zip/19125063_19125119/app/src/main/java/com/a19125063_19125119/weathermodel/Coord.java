package com.a19125063_19125119.weathermodel;

public class Coord {
    public double lon;
    public double lat;
}
