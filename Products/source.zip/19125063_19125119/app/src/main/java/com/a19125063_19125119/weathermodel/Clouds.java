package com.a19125063_19125119.weathermodel;

public class Clouds {
    public int all;
}
