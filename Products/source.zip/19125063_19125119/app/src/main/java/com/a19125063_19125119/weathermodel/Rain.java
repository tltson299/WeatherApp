package com.a19125063_19125119.weathermodel;

import com.google.gson.annotations.SerializedName;

public class Rain {
    @SerializedName("3h")
    public double _3h;
}
