package com.a19125063_19125119.weathermodel;

import java.util.List;

public class WeatherDetail {
    public String cod;
    public int message;
    public int cnt;
    public List<WeatherList> list;
    public City city;
}
